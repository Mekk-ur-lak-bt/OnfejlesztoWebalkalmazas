import { Modal } from "../ui/Modal.js";

const TEMAK = {
  girlipop: {
    "--szin-tema-hatter": "#ede2e4",
    "--szin-tema-hatter-eltero": "#e3d9f5",
    "--szin-tema-szegely": "#bb8a8e",
    "--szin-tema-mely": "#efa4af",
    "--szin-tema-kiemelt": "#a43953",
    "--szin-vilagos": "#ff8fab",
    "--szin-kozepes": "#fb6f92",
    "--szin-sotet": "#5c1111",
    "--szin-halvany": "#ffe5ec",
    "--szin-kiemelt": "#f12349",
    "--szinatmenet":
      "linear-gradient(180deg, rgb(255 255 255 / 97%) 0%, rgb(253 129 154 / 94%) 100%)",
    "--szinatmenet-hatter":
      "radial-gradient(circle at center, rgb(222 209 229 / 97%) 90%, rgb(176 160 185 / 94%) 100%)",
    "--szoveg-alap": "#5e4349",
    "--szoveg-alcim": "#603e45",
    "--szoveg-kiemelt": "#680c1f",
    "--betu-dekor": '"Cinzel Decorative", serif',
    "--betu-serif": '"Noto Serif SC", serif',
    "--betu-sans": '"Rajdhani", sans-serif',
    "--betu-mono": '"Share Tech Mono", monospace',
  },
  elegans: {
    "--szin-tema-hatter": "#0d1b2a",
    "--szin-tema-hatter-eltero": "#1b2a3b",
    "--szin-tema-szegely": "#b8972a",
    "--szin-tema-mely": "#1e3a5f",
    "--szin-tema-kiemelt": "#c9a84c",
    "--szin-vilagos": "#d4af37",
    "--szin-kozepes": "#b8972a",
    "--szin-sotet": "#0a0f1e",
    "--szin-halvany": "#1a2744",
    "--szin-kiemelt": "#f0c040",
    "--szinatmenet":
      "linear-gradient(180deg, rgb(13 27 42 / 97%) 0%, rgb(30 58 95 / 94%) 100%)",
    "--szinatmenet-hatter":
      "radial-gradient(circle at center, rgb(13 27 42 / 97%) 90%, rgb(10 15 30 / 94%) 100%)",
    "--szoveg-alap": "#d4c5a9",
    "--szoveg-alcim": "#c9b99a",
    "--szoveg-kiemelt": "#f0c040",
    "--betu-dekor": '"Cinzel Decorative", serif',
    "--betu-serif": '"Noto Serif SC", serif',
    "--betu-sans": '"Rajdhani", sans-serif',
    "--betu-mono": '"Share Tech Mono", monospace',
  },
  termeszet: {
    "--szin-tema-hatter": "#d6dfd4",
    "--szin-tema-hatter-eltero": "#c9d9c7",
    "--szin-tema-szegely": "#7a9e7e",
    "--szin-tema-mely": "#4a7c59",
    "--szin-tema-kiemelt": "#2d5a3d",
    "--szin-vilagos": "#a8c5a0",
    "--szin-kozepes": "#6b9e6e",
    "--szin-sotet": "#1a3320",
    "--szin-halvany": "#e8f0e6",
    "--szin-kiemelt": "#3d7a4a",
    "--szinatmenet":
      "linear-gradient(180deg, rgb(214 223 212 / 97%) 0%, rgb(106 158 110 / 94%) 100%)",
    "--szinatmenet-hatter":
      "radial-gradient(circle at center, rgb(190 210 188 / 97%) 90%, rgb(130 160 133 / 94%) 100%)",
    "--szoveg-alap": "#2c4a30",
    "--szoveg-alcim": "#3a5c3e",
    "--szoveg-kiemelt": "#1a3320",
    "--betu-dekor": '"Cinzel Decorative", serif',
    "--betu-serif": '"Noto Serif SC", serif',
    "--betu-sans": '"Rajdhani", sans-serif',
    "--betu-mono": '"Share Tech Mono", monospace',
  },
};

const TEMA_KULCS = "tema";

export class TemaValaszto {
  #modal;

  constructor() {
    this.#modal = new Modal(
      "tema-modal",
      `
      <h3>Choose Theme</h3>
      <div class="tema-valasztok">
        <div class="tema-kartya" data-tema="girlipop">
          <div class="tema-elonezet tema-girlipop"></div>
          <span>GirliePop</span>
        </div>
        <div class="tema-kartya" data-tema="elegans">
          <div class="tema-elonezet tema-elegans"></div>
          <span>Elegant</span>
        </div>
        <div class="tema-kartya" data-tema="termeszet">
          <div class="tema-elonezet tema-termeszet"></div>
          <span>Nature</span>
        </div>
      </div>
      <div class="modal-gombok">
        <button type="button" id="tema-megse">Cancel</button>
      </div>
    `,
    );

    this.#modal
      .keres("#tema-megse")
      .addEventListener("click", () => this.#modal.bezar());

    this.#modal.keresOsszes(".tema-kartya").forEach((kartya) => {
      kartya.addEventListener("click", () => {
        this.#alkalmazTema(kartya.dataset.tema);
        this.#modal.bezar();
      });
    });

    document.getElementById("settings").addEventListener("click", (e) => {
      e.preventDefault();
      this.#modal.megnyit();
    });

    this.#alkalmazTema(localStorage.getItem(TEMA_KULCS) ?? "girlipop");
  }

  #alkalmazTema(nev) {
    const tema = TEMAK[nev] ?? TEMAK.girlipop;
    Object.entries(tema).forEach(([valtozo, ertek]) => {
      document.documentElement.style.setProperty(valtozo, ertek);
    });
    localStorage.setItem(TEMA_KULCS, nev);
  }
}
